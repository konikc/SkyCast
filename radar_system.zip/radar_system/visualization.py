"""
Визуализация: рендер интерполированного поля осадков в PNG по радарной шкале.
"""
from __future__ import annotations

import logging

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap, BoundaryNorm

from config import RADAR_COLOR_SCALE

log = logging.getLogger("radar.visualization")


def _build_colormap():
    positions = [v / 5.0 for v, _ in RADAR_COLOR_SCALE]
    colors = [tuple(c / 255 for c in rgba) for _, rgba in RADAR_COLOR_SCALE]
    cmap = LinearSegmentedColormap.from_list("radar_scale", list(zip(positions, colors)), N=256)
    return cmap


def render_district(
    grid_lon: np.ndarray,
    grid_lat: np.ndarray,
    z: np.ndarray,
    district_name: str,
    out_path: str = "radar_output.png",
    points: tuple[np.ndarray, np.ndarray] | None = None,
):
    """Сохраняет PNG с наложением интерполированного поля осадков."""
    cmap = _build_colormap()

    fig, ax = plt.subplots(figsize=(10, 10), dpi=150)
    ax.set_facecolor("#0e1a2b")

    mesh = ax.pcolormesh(
        grid_lon, grid_lat, z,
        cmap=cmap, vmin=0, vmax=5, shading="auto", alpha=0.85,
    )

    if points is not None:
        pt_lon, pt_lat = points
        ax.scatter(pt_lon, pt_lat, s=6, c="white", edgecolors="black", linewidths=0.3, zorder=5)

    ax.set_title(f"Радар осадков (эмуляция) — {district_name}", fontsize=14, color="white")
    ax.set_xlabel("Долгота")
    ax.set_ylabel("Широта")
    ax.set_aspect("equal")

    cbar = fig.colorbar(mesh, ax=ax, shrink=0.75, pad=0.02)
    cbar.set_label("Интенсивность осадков (0–5)")

    fig.patch.set_facecolor("#0e1a2b")
    ax.tick_params(colors="white")
    ax.xaxis.label.set_color("white")
    ax.yaxis.label.set_color("white")

    fig.savefig(out_path, transparent=False, bbox_inches="tight")
    plt.close(fig)
    log.info("Сохранён файл: %s", out_path)
    return out_path
