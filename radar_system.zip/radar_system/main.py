"""
Точка входа: запускает сбор данных, интерполяцию и визуализацию.

Использование:
    python main.py --district ЦФО --once
    python main.py --district ПФО --loop --interval 600
"""
from __future__ import annotations

import argparse
import asyncio
import logging
import sys

from config import FEDERAL_DISTRICTS_BBOX
from aggregator import collect_all
from interpolation import interpolate_district
from visualization import render_district

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)
log = logging.getLogger("radar.main")


async def run_cycle(district: str, out_path: str) -> bool:
    log.info("=== Запуск цикла сбора для округа %s ===", district)
    df = await collect_all()

    if df.empty:
        log.error("Нет данных ни от одного источника — пропуск цикла.")
        return False

    result = interpolate_district(df, district)
    if result is None:
        log.error("Интерполяция для округа %s не удалась (недостаточно точек в bbox).", district)
        return False

    grid_lon, grid_lat, z = result

    subset = df[
        (df["longitude"] >= FEDERAL_DISTRICTS_BBOX[district][0]) &
        (df["longitude"] <= FEDERAL_DISTRICTS_BBOX[district][2]) &
        (df["latitude"] >= FEDERAL_DISTRICTS_BBOX[district][1]) &
        (df["latitude"] <= FEDERAL_DISTRICTS_BBOX[district][3])
    ]
    points = (subset["longitude"].to_numpy(), subset["latitude"].to_numpy())

    render_district(grid_lon, grid_lat, z, district, out_path=out_path, points=points)
    log.info("=== Цикл завершён успешно ===")
    return True


async def loop_forever(district: str, out_path: str, interval: int):
    while True:
        try:
            await run_cycle(district, out_path)
        except Exception as exc:
            log.error("Необработанная ошибка в цикле: %s", exc, exc_info=True)
        log.info("Ожидание %d секунд до следующего цикла...", interval)
        await asyncio.sleep(interval)


def parse_args():
    parser = argparse.ArgumentParser(description="Самодельный метеорадар осадков (РФ)")
    parser.add_argument(
        "--district", default="ЦФО",
        choices=list(FEDERAL_DISTRICTS_BBOX.keys()),
        help="Федеральный округ для построения радарной карты",
    )
    parser.add_argument("--out", default="radar_output.png", help="Путь для сохранения PNG")
    parser.add_argument("--loop", action="store_true", help="Запуск в режиме бесконечного цикла")
    parser.add_argument("--once", action="store_true", help="Однократный запуск (по умолчанию)")
    parser.add_argument("--interval", type=int, default=600, help="Интервал цикла в секундах (по умолчанию 600 = 10 мин)")
    return parser.parse_args()


def main():
    args = parse_args()
    if args.loop:
        asyncio.run(loop_forever(args.district, args.out, args.interval))
    else:
        ok = asyncio.run(run_cycle(args.district, args.out))
        sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
