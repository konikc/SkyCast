"""
Построение сетки и радиально-базисная интерполяция (эмуляция сплошного радарного поля).
"""
from __future__ import annotations

import logging

import numpy as np
import pandas as pd
from scipy.interpolate import Rbf

from config import FEDERAL_DISTRICTS_BBOX

log = logging.getLogger("radar.interpolation")

# Шаг сетки в градусах (~1-2 км по широте средних широт РФ)
GRID_STEP_DEG = 0.015  # ~1.6 км


def build_grid(bbox: tuple[float, float, float, float], step: float = GRID_STEP_DEG):
    min_lon, min_lat, max_lon, max_lat = bbox
    lons = np.arange(min_lon, max_lon, step)
    lats = np.arange(min_lat, max_lat, step)
    grid_lon, grid_lat = np.meshgrid(lons, lats)
    return grid_lon, grid_lat


def interpolate_district(
    df: pd.DataFrame,
    district: str,
    step: float = GRID_STEP_DEG,
    smooth: float = 0.1,
) -> tuple[np.ndarray, np.ndarray, np.ndarray] | None:
    """Возвращает (grid_lon, grid_lat, Z) для указанного округа, либо None если данных недостаточно."""
    if district not in FEDERAL_DISTRICTS_BBOX:
        raise ValueError(f"Неизвестный округ: {district}")

    bbox = FEDERAL_DISTRICTS_BBOX[district]
    min_lon, min_lat, max_lon, max_lat = bbox

    subset = df[
        (df["longitude"] >= min_lon) & (df["longitude"] <= max_lon) &
        (df["latitude"] >= min_lat) & (df["latitude"] <= max_lat)
    ]

    if len(subset) < 3:
        log.warning("Округ %s: недостаточно точек (%d) для интерполяции.", district, len(subset))
        return None

    grid_lon, grid_lat = build_grid(bbox, step)

    try:
        rbf = Rbf(
            subset["longitude"].to_numpy(),
            subset["latitude"].to_numpy(),
            subset["intensity"].to_numpy(),
            function="multiquadric",
            smooth=smooth,
        )
        z = rbf(grid_lon, grid_lat)
        z = np.clip(z, 0, 5)
    except Exception as exc:
        log.error("Округ %s: ошибка интерполяции: %s", district, exc)
        return None

    return grid_lon, grid_lat, z
