"""
Асинхронные парсеры данных с различных источников.

ВАЖНО (честное предупреждение по надёжности источников):
- METAR (aviationweather.gov) — публичный, стабильный, документированный API. Работает надёжно.
- WMO/WWIS (worldweather.wmo.int) — публичный, но неофициальный формат JSON; поля могут
  меняться без предупреждения, поэтому парсер сделан отказоустойчивым (try/except на каждом шаге).
- СКДФ/Росавтодор — Я НЕ НАШЁЛ задокументированного публичного WFS/REST эндпоинта СКДФ.
  Это внутренний ведомственный сервис, и его точный URL/схема мне неизвестны и могут не
  существовать в описанном виде. Ниже дана РАБОЧАЯ ЗАГОТОВКА (адаптер), которую нужно
  донастроить: подставьте реальный URL эндпоинта, если у вас есть к нему легальный доступ
  (например, через открытый портал данных Росавтодора), либо замените на другой источник
  дорожной метеоинформации, к которому у вас есть доступ. Без этого модуль вернёт пустой список.
- RainViewer — публичный, документированный API, используется только для калибровки/подложки.
"""
from __future__ import annotations

import re
import asyncio
import logging
from typing import Optional

import httpx

from config import (
    RUSSIAN_ICAO_CODES,
    WMO_WEATHER_TEXT_MAP,
    REQUEST_TIMEOUT,
    USER_AGENT,
)

log = logging.getLogger("radar.parsers")

HEADERS = {"User-Agent": USER_AGENT}

# --------------------------------------------------------------------------
# 1. METAR (aviationweather.gov)
# --------------------------------------------------------------------------

_METAR_PATTERNS = [
    (re.compile(r"\+SHRA"), 4.0),
    (re.compile(r"\bSHRA\b"), 3.5),
    (re.compile(r"\bTSRA\b|\bTS\b"), 5.0),
    (re.compile(r"\+RA\b"), 3.5),
    (re.compile(r"\bRA\b"), 2.5),
    (re.compile(r"\+SN\b"), 3.5),
    (re.compile(r"\bSN\b"), 2.5),
    (re.compile(r"-SN\b"), 1.5),
    (re.compile(r"-DZ\b"), 1.0),
    (re.compile(r"\bDZ\b"), 1.0),
]


def _intensity_from_metar_text(raw: str) -> float:
    if not raw:
        return 0.0
    best = 0.0
    for pattern, weight in _METAR_PATTERNS:
        if pattern.search(raw):
            best = max(best, weight)
    return best


async def fetch_metar(client: httpx.AsyncClient, icao_codes: list[str]) -> list[dict]:
    """Забирает METAR для списка ICAO-кодов и возвращает [{lat, lon, intensity, source}]."""
    results: list[dict] = []
    ids_param = ",".join(icao_codes)
    url = f"https://aviationweather.gov/api/data/metar?ids={ids_param}&format=json"
    try:
        resp = await client.get(url, headers=HEADERS, timeout=REQUEST_TIMEOUT)
        resp.raise_for_status()
        data = resp.json()
    except Exception as exc:  # сеть, парсинг JSON, HTTP-ошибка и т.д.
        log.warning("METAR: запрос не удался: %s", exc)
        return results

    for station in data if isinstance(data, list) else []:
        try:
            lat = station.get("lat")
            lon = station.get("lon")
            raw = station.get("rawOb") or station.get("metar") or ""
            wx = station.get("wxString") or ""
            if lat is None or lon is None:
                continue
            intensity = _intensity_from_metar_text(raw) or _intensity_from_metar_text(wx)
            results.append({
                "latitude": float(lat),
                "longitude": float(lon),
                "intensity": float(intensity),
                "source": "METAR",
            })
        except Exception as exc:
            log.debug("METAR: пропущена станция из-за ошибки парсинга: %s", exc)
            continue
    return results


# --------------------------------------------------------------------------
# 2. WMO / WWIS
# --------------------------------------------------------------------------

async def fetch_wmo_russia_city_ids(client: httpx.AsyncClient) -> list[tuple[str, str]]:
    """Скачивает реестр городов WMO и отбирает станции РФ. Возвращает [(city_id, city_name)]."""
    url = "https://worldweather.wmo.int/en/json/full_city_list.txt"
    out: list[tuple[str, str]] = []
    try:
        resp = await client.get(url, headers=HEADERS, timeout=REQUEST_TIMEOUT)
        resp.raise_for_status()
        data = resp.json()
    except Exception as exc:
        log.warning("WMO: не удалось скачать реестр городов: %s", exc)
        return out

    # Формат ответа WMO исторически представляет собой dict вида {"member": [...]}
    members = data.get("member") if isinstance(data, dict) else data
    if not isinstance(members, list):
        log.warning("WMO: неожиданный формат реестра городов")
        return out

    for entry in members:
        try:
            country = str(entry.get("countryName") or entry.get("country") or "")
            if "russia" in country.lower():
                city_id = str(entry.get("cityId") or entry.get("city_id"))
                city_name = str(entry.get("cityName") or entry.get("city") or "")
                if city_id and city_id != "None":
                    out.append((city_id, city_name))
        except Exception:
            continue
    return out


def _intensity_from_wmo_text(text: str) -> float:
    if not text:
        return 0.0
    t = text.lower()
    best = 0.0
    for phrase, weight in WMO_WEATHER_TEXT_MAP.items():
        if phrase in t:
            best = max(best, weight)
    return best


async def fetch_wmo_station(client: httpx.AsyncClient, city_id: str, city_name: str) -> Optional[dict]:
    url = f"https://worldweather.wmo.int/en/json/{city_id}_en.json"
    try:
        resp = await client.get(url, headers=HEADERS, timeout=REQUEST_TIMEOUT)
        resp.raise_for_status()
        data = resp.json()
    except Exception as exc:
        log.debug("WMO: станция %s (%s) недоступна: %s", city_name, city_id, exc)
        return None

    try:
        city_block = data.get("city", {})
        lat = city_block.get("cityLatitude") or city_block.get("latitude")
        lon = city_block.get("cityLongitude") or city_block.get("longitude")
        present = city_block.get("presentWeather") or city_block.get("weatherDescription") or ""
        if lat is None or lon is None:
            return None
        intensity = _intensity_from_wmo_text(str(present))
        return {
            "latitude": float(lat),
            "longitude": float(lon),
            "intensity": intensity,
            "source": "WMO",
        }
    except Exception as exc:
        log.debug("WMO: ошибка парсинга станции %s: %s", city_name, exc)
        return None


async def fetch_wmo_all(client: httpx.AsyncClient, limit: Optional[int] = None) -> list[dict]:
    stations = await fetch_wmo_russia_city_ids(client)
    if limit:
        stations = stations[:limit]
    if not stations:
        return []
    tasks = [fetch_wmo_station(client, cid, name) for cid, name in stations]
    results = await asyncio.gather(*tasks, return_exceptions=False)
    return [r for r in results if r]


# --------------------------------------------------------------------------
# 3. Дорожные метеостанции (СКДФ / Росавтодор) — АДАПТЕР, ТРЕБУЕТ НАСТРОЙКИ
# --------------------------------------------------------------------------

# Замените на реальный проверенный эндпоинт, если он у вас есть.
SKDF_GEOSERVER_URL = None  # например: "https://skdf.example.ru/geoserver/wfs?...&outputFormat=application/json"

_SKDF_PRECIP_MAP = {
    "сухо": 0.0, "ясно": 0.0,
    "морось": 1.0,
    "дождь": 2.5,
    "сильный дождь": 4.0,
    "снег": 2.5,
    "сильный снег": 3.5,
    "гроза": 5.0,
}


async def fetch_skdf(client: httpx.AsyncClient) -> list[dict]:
    """
    Возвращает данные дорожных метеостанций, если SKDF_GEOSERVER_URL настроен и доступен.
    Если URL не задан или запрос не удался — возвращает пустой список (без падения системы).
    """
    if not SKDF_GEOSERVER_URL:
        log.info("СКДФ: эндпоинт не настроен (SKDF_GEOSERVER_URL is None), источник пропущен.")
        return []

    results: list[dict] = []
    try:
        resp = await client.get(SKDF_GEOSERVER_URL, headers=HEADERS, timeout=REQUEST_TIMEOUT)
        resp.raise_for_status()
        data = resp.json()
    except Exception as exc:
        log.warning("СКДФ: запрос к геосерверу не удался: %s", exc)
        return results

    for feature in data.get("features", []) if isinstance(data, dict) else []:
        try:
            geom = feature.get("geometry", {})
            coords = geom.get("coordinates")
            props = feature.get("properties", {})
            if not coords or len(coords) < 2:
                continue
            lon, lat = coords[0], coords[1]
            raw_state = (
                props.get("weather_state")
                or props.get("precip_type")
                or props.get("precipitation")
                or ""
            )
            intensity = _SKDF_PRECIP_MAP.get(str(raw_state).strip().lower(), 0.0)
            results.append({
                "latitude": float(lat),
                "longitude": float(lon),
                "intensity": float(intensity),
                "source": "SKDF",
            })
        except Exception as exc:
            log.debug("СКДФ: пропущена станция из-за ошибки парсинга: %s", exc)
            continue
    return results


# --------------------------------------------------------------------------
# 4. RainViewer (калибровка/подложка)
# --------------------------------------------------------------------------

async def fetch_rainviewer_latest_tile_template(client: httpx.AsyncClient) -> Optional[str]:
    """Возвращает URL-шаблон последнего радарного слоя RainViewer или None."""
    url = "https://api.rainviewer.com/public/weather-maps.json"
    try:
        resp = await client.get(url, headers=HEADERS, timeout=REQUEST_TIMEOUT)
        resp.raise_for_status()
        data = resp.json()
    except Exception as exc:
        log.warning("RainViewer: запрос не удался: %s", exc)
        return None

    try:
        radar = data.get("radar", {})
        frames = radar.get("past") or radar.get("nowcast") or []
        if not frames:
            return None
        last = frames[-1]
        path = last.get("path")
        if not path:
            return None
        return f"https://tilecache.rainviewer.com{path}/256/{{z}}/{{x}}/{{y}}/1/1_1.png"
    except Exception as exc:
        log.debug("RainViewer: ошибка парсинга метаданных: %s", exc)
        return None
