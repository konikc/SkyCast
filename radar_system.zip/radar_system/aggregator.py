"""
Агрегация данных со всех источников в единый DataFrame и дедупликация.
"""
from __future__ import annotations

import logging
import math

import httpx
import pandas as pd

from config import RUSSIAN_ICAO_CODES, REQUEST_TIMEOUT
import parsers

log = logging.getLogger("radar.aggregator")

DEDUP_RADIUS_KM = 1.0


def _haversine_km(lat1, lon1, lat2, lon2) -> float:
    r = 6371.0
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dphi = math.radians(lat2 - lat1)
    dlambda = math.radians(lon2 - lon1)
    a = math.sin(dphi / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dlambda / 2) ** 2
    return 2 * r * math.asin(min(1.0, math.sqrt(a)))


def deduplicate(df: pd.DataFrame, radius_km: float = DEDUP_RADIUS_KM) -> pd.DataFrame:
    """Если станции находятся в радиусе radius_km друг от друга — оставляет максимум intensity.

    Реализация O(n^2), приемлема для десятков-сотен точек за цикл сбора (не миллионов).
    Для большего масштаба стоит заменить на пространственный индекс (например, scipy.cKDTree).
    """
    if df.empty:
        return df

    df = df.reset_index(drop=True)
    keep = [True] * len(df)
    coords = df[["latitude", "longitude"]].to_numpy()
    intensities = df["intensity"].to_numpy()

    for i in range(len(df)):
        if not keep[i]:
            continue
        for j in range(i + 1, len(df)):
            if not keep[j]:
                continue
            dist = _haversine_km(coords[i][0], coords[i][1], coords[j][0], coords[j][1])
            if dist <= radius_km:
                # оставляем точку с максимальной интенсивностью, вторую убираем
                if intensities[j] > intensities[i]:
                    keep[i] = False
                    break
                else:
                    keep[j] = False

    return df[keep].reset_index(drop=True)


async def collect_all(wmo_limit: int | None = 150) -> pd.DataFrame:
    """Запускает все парсеры параллельно и возвращает единый DataFrame [latitude, longitude, intensity, source]."""
    records: list[dict] = []

    limits = httpx.Limits(max_connections=20, max_keepalive_connections=10)
    async with httpx.AsyncClient(limits=limits, follow_redirects=True) as client:
        metar_task = parsers.fetch_metar(client, RUSSIAN_ICAO_CODES)
        wmo_task = parsers.fetch_wmo_all(client, limit=wmo_limit)
        skdf_task = parsers.fetch_skdf(client)

        metar_res, wmo_res, skdf_res = await __import__("asyncio").gather(
            metar_task, wmo_task, skdf_task, return_exceptions=True
        )

    for name, res in (("METAR", metar_res), ("WMO", wmo_res), ("SKDF", skdf_res)):
        if isinstance(res, Exception):
            log.error("Источник %s завершился с ошибкой: %s", name, res)
            continue
        records.extend(res)

    if not records:
        log.warning("Ни один источник не вернул данных.")
        return pd.DataFrame(columns=["latitude", "longitude", "intensity", "source"])

    df = pd.DataFrame.from_records(records)
    df = df.dropna(subset=["latitude", "longitude"])
    df["intensity"] = df["intensity"].clip(lower=0.0, upper=5.0)

    before = len(df)
    df = deduplicate(df)
    log.info("Агрегация: %d точек до дедупликации, %d после.", before, len(df))
    return df
